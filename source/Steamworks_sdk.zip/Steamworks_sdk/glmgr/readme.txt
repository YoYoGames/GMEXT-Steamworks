================================================================

Copyright � 1996-2011, Valve Corporation, All rights reserved.

================================================================

OSX DirectX to OpenGL Conversion Library

Contains all support files required to assist in converting DirectX applications to OpenGL on OSX. For reference,
this library can be enabled in the Steamworks Example by building with the compile time flag DX9MODE=1.

